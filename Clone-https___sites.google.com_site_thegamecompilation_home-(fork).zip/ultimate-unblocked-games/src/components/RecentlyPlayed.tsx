import { FC, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { gameData, Game } from '../data/games';

interface PlayHistoryItem {
  gameId: string;
  lastPlayed: string;
  playCount: number;
}

interface RecentlyPlayedProps {
  limit?: number;
}

const RecentlyPlayed: FC<RecentlyPlayedProps> = ({ limit = 5 }) => {
  const [recentGames, setRecentGames] = useState<Game[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadRecentGames = () => {
      const playHistory: PlayHistoryItem[] = JSON.parse(localStorage.getItem('playHistory') || '[]');

      if (playHistory.length === 0) {
        setRecentGames([]);
        setLoading(false);
        return;
      }

      // Sort by last played date (most recent first)
      const sortedHistory = [...playHistory].sort((a, b) =>
        new Date(b.lastPlayed).getTime() - new Date(a.lastPlayed).getTime()
      );

      // Get unique game IDs (in case there are duplicates)
      const uniqueGameIds = Array.from(new Set(sortedHistory.map(item => item.gameId)));

      // Get the game objects for these IDs
      const games = uniqueGameIds
        .map(id => gameData.find(game => game.id === id))
        .filter((game): game is Game => game !== undefined)
        .slice(0, limit);

      setRecentGames(games);
      setLoading(false);
    };

    loadRecentGames();

    // Listen for storage changes to update the list
    window.addEventListener('storage', loadRecentGames);

    return () => {
      window.removeEventListener('storage', loadRecentGames);
    };
  }, [limit]);

  if (loading) {
    return <div className="py-4">Loading recently played games...</div>;
  }

  if (recentGames.length === 0) {
    return null;
  }

  return (
    <div className="mb-8">
      <h2 className="section-title">Recently Played</h2>
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
        {recentGames.map(game => (
          <div key={game.id}>
            <Link
              to={`/game/${game.id}`}
              className="game-tab"
            >
              <h3 className="title">{game.title}</h3>
              <p className="category">{game.categories[0]}</p>
              <span className="play-button">Play Again</span>
            </Link>
          </div>
        ))}
      </div>
    </div>
  );
};

export default RecentlyPlayed;
