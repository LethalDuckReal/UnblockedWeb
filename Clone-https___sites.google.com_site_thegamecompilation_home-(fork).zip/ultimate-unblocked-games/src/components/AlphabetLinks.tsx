import { FC } from 'react';
import { Link } from 'react-router-dom';

const AlphabetLinks: FC = () => {
  const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');

  return (
    <div className="my-6 bg-white p-4 rounded-lg shadow-md">
      <div className="flex flex-wrap justify-center gap-2">
        {alphabet.map(letter => (
          <Link
            key={letter}
            to={`/category/letter-${letter.toLowerCase()}`}
            className="flex h-9 w-9 items-center justify-center rounded-md bg-blue-600 text-white hover:bg-blue-700 transition-colors shadow"
          >
            {letter}
          </Link>
        ))}
        <Link
          to="/category/letter-0-9"
          className="flex h-9 w-9 items-center justify-center rounded-md bg-blue-600 text-white hover:bg-blue-700 transition-colors shadow"
        >
          0-9
        </Link>
      </div>
    </div>
  );
};

export default AlphabetLinks;
