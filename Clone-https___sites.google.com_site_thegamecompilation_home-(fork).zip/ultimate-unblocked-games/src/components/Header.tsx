import { FC, useState, useEffect, useContext } from 'react';
import { Link, useLocation } from 'react-router-dom';
import SearchBar from './SearchBar';
import { ThemeContext } from '../context/ThemeContext';

const Header: FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [favoritesCount, setFavoritesCount] = useState(0);
  const location = useLocation();
  const { darkMode, toggleDarkMode } = useContext(ThemeContext);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  // Update favorites count when localStorage changes
  useEffect(() => {
    const updateFavoritesCount = () => {
      const favorites = JSON.parse(localStorage.getItem('favorites') || '[]');
      setFavoritesCount(favorites.length);
    };

    // Initial count
    updateFavoritesCount();

    // Listen for changes in localStorage
    window.addEventListener('storage', updateFavoritesCount);

    // Custom event for internal updates
    window.addEventListener('favoritesUpdated', updateFavoritesCount);

    return () => {
      window.removeEventListener('storage', updateFavoritesCount);
      window.removeEventListener('favoritesUpdated', updateFavoritesCount);
    };
  }, []);

  // Close mobile menu when route changes
  useEffect(() => {
    setIsMenuOpen(false);
  }, [location.pathname]);

  return (
    <header className={`${darkMode ? 'bg-gray-800' : 'bg-blue-600'} text-white shadow-md transition-colors duration-200`}>
      <div className="container-custom">
        <div className="flex items-center justify-between py-4">
          <Link to="/" className="flex items-center space-x-2">
            <svg
              className="h-8 w-8"
              viewBox="0 0 24 24"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M6 11h4M8 9v4M15 12h.01M18 10h.01M17.5 15a3.5 3.5 0 1 1 0-7 3.5 3.5 0 0 1 0 7zm-11 0a3.5 3.5 0 1 1 0-7 3.5 3.5 0 0 1 0 7z"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <path
                d="M21 12c0 1.66-4.03 3-9 3s-9-1.34-9-3"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <path
                d="M3 12v-2c0-1.1 4.03-2 9-2s9 .9 9 2v2"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
            <span className="text-xl font-bold md:text-2xl">Ultimate Unblocked Games</span>
          </Link>

          {/* Search Bar - visible on medium screens and up */}
          <div className="hidden md:block md:w-1/3">
            <SearchBar />
          </div>

          {/* Mobile menu button and icons */}
          <div className="flex items-center md:hidden">
            <Link
              to="/favorites"
              className="mr-4 relative"
              aria-label="Favorites"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 24 24"
                fill="currentColor"
                className="h-6 w-6"
              >
                <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" />
              </svg>
              {favoritesCount > 0 && (
                <span className="absolute -top-2 -right-2 flex h-5 w-5 items-center justify-center rounded-full bg-red-500 text-xs font-bold">
                  {favoritesCount}
                </span>
              )}
            </Link>

            <button
              className={`mr-3 rounded p-2 ${darkMode ? 'hover:bg-gray-700' : 'hover:bg-blue-700'}`}
              onClick={toggleDarkMode}
              aria-label={darkMode ? 'Switch to light mode' : 'Switch to dark mode'}
            >
              {darkMode ? (
                <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z"
                  />
                </svg>
              ) : (
                <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"
                  />
                </svg>
              )}
            </button>

            <button
              className={`block rounded p-2 ${darkMode ? 'hover:bg-gray-700' : 'hover:bg-blue-700'} md:hidden`}
              onClick={toggleMenu}
              aria-expanded={isMenuOpen}
              aria-label="Toggle menu"
            >
              <svg
                className="h-6 w-6"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                {isMenuOpen ? (
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M6 18L18 6M6 6l12 12"
                  />
                ) : (
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M4 6h16M4 12h16m-7 6h7"
                  />
                )}
              </svg>
            </button>
          </div>

          {/* Desktop Menu */}
          <nav className="hidden md:flex md:items-center">
            <ul className="flex space-x-4 items-center">
              <li>
                <Link to="/" className="hover:text-blue-200 dark:hover:text-gray-300">
                  Home
                </Link>
              </li>
              <li>
                <Link to="/category/new" className="hover:text-blue-200 dark:hover:text-gray-300">
                  New Games
                </Link>
              </li>
              <li>
                <Link to="/category/popular" className="hover:text-blue-200 dark:hover:text-gray-300">
                  Popular Games
                </Link>
              </li>
              <li>
                <Link to="/crazygames" className="hover:text-blue-200 dark:hover:text-gray-300">
                  CrazyGames
                </Link>
              </li>
              <li>
                <Link to="/category/io" className="hover:text-blue-200 dark:hover:text-gray-300">
                  IO Games
                </Link>
              </li>
              <li>
                <Link
                  to="/favorites"
                  className="relative flex items-center space-x-1 hover:text-blue-200 dark:hover:text-gray-300"
                  aria-label="My favorites"
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    viewBox="0 0 24 24"
                    fill="currentColor"
                    className="h-5 w-5"
                  >
                    <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" />
                  </svg>
                  <span>Favorites</span>
                  {favoritesCount > 0 && (
                    <span className="ml-1 flex h-5 w-5 items-center justify-center rounded-full bg-red-500 text-xs font-bold">
                      {favoritesCount}
                    </span>
                  )}
                </Link>
              </li>
              <li>
                <button
                  className={`rounded-full p-2 ${darkMode ? 'bg-gray-700 hover:bg-gray-600' : 'bg-blue-700 hover:bg-blue-800'}`}
                  onClick={toggleDarkMode}
                  aria-label={darkMode ? 'Switch to light mode' : 'Switch to dark mode'}
                >
                  {darkMode ? (
                    <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z"
                      />
                    </svg>
                  ) : (
                    <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"
                      />
                    </svg>
                  )}
                </button>
              </li>
            </ul>
          </nav>
        </div>

        {/* Mobile Search - visible only on small screens */}
        {isMenuOpen && (
          <div className="pt-4 pb-2 md:hidden">
            <SearchBar />
          </div>
        )}

        {/* Mobile Menu */}
        {isMenuOpen && (
          <nav className={`border-t ${darkMode ? 'border-gray-700' : 'border-blue-500'} py-4 md:hidden`}>
            <ul className="space-y-4">
              <li>
                <Link
                  to="/"
                  className={`block px-2 py-1 ${darkMode ? 'hover:bg-gray-700' : 'hover:bg-blue-700'}`}
                  onClick={toggleMenu}
                >
                  Home
                </Link>
              </li>
              <li>
                <Link
                  to="/category/new"
                  className={`block px-2 py-1 ${darkMode ? 'hover:bg-gray-700' : 'hover:bg-blue-700'}`}
                  onClick={toggleMenu}
                >
                  New Games
                </Link>
              </li>
              <li>
                <Link
                  to="/category/popular"
                  className={`block px-2 py-1 ${darkMode ? 'hover:bg-gray-700' : 'hover:bg-blue-700'}`}
                  onClick={toggleMenu}
                >
                  Popular Games
                </Link>
              </li>
              <li>
                <Link
                  to="/crazygames"
                  className={`block px-2 py-1 ${darkMode ? 'hover:bg-gray-700' : 'hover:bg-blue-700'}`}
                  onClick={toggleMenu}
                >
                  CrazyGames
                </Link>
              </li>
              <li>
                <Link
                  to="/category/io"
                  className={`block px-2 py-1 ${darkMode ? 'hover:bg-gray-700' : 'hover:bg-blue-700'}`}
                  onClick={toggleMenu}
                >
                  IO Games
                </Link>
              </li>
              <li>
                <Link
                  to="/favorites"
                  className={`flex items-center px-2 py-1 ${darkMode ? 'hover:bg-gray-700' : 'hover:bg-blue-700'}`}
                  onClick={toggleMenu}
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    viewBox="0 0 24 24"
                    fill="currentColor"
                    className="h-5 w-5 mr-2"
                  >
                    <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" />
                  </svg>
                  <span>My Favorites</span>
                  {favoritesCount > 0 && (
                    <span className="ml-2 inline-block rounded-full bg-red-500 px-2 py-0.5 text-xs font-bold">
                      {favoritesCount}
                    </span>
                  )}
                </Link>
              </li>
            </ul>
          </nav>
        )}
      </div>
    </header>
  );
};

export default Header;
