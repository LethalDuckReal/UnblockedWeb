import { FC, useContext } from 'react';
import { Link } from 'react-router-dom';
import { ThemeContext } from '../context/ThemeContext';

const Footer: FC = () => {
  const currentYear = new Date().getFullYear();
  const { darkMode } = useContext(ThemeContext);

  return (
    <footer className={`${darkMode ? 'bg-gray-800' : 'bg-blue-800'} py-10 text-white transition-colors duration-200`}>
      <div className="container-custom">
        <div className="grid grid-cols-1 gap-8 md:grid-cols-4">
          <div>
            <h3 className="mb-4 text-lg font-semibold text-white">Ultimate Unblocked Games</h3>
            <p className="text-gray-300">
              The best collection of unblocked games from all around the web, available to play
              anywhere, anytime.
            </p>
          </div>

          <div>
            <h3 className="mb-4 text-lg font-semibold text-white">Categories</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/category/action" className="text-gray-300 hover:text-white">
                  Action Games
                </Link>
              </li>
              <li>
                <Link to="/category/arcade" className="text-gray-300 hover:text-white">
                  Arcade Games
                </Link>
              </li>
              <li>
                <Link to="/category/puzzle" className="text-gray-300 hover:text-white">
                  Puzzle Games
                </Link>
              </li>
              <li>
                <Link to="/category/racing" className="text-gray-300 hover:text-white">
                  Racing Games
                </Link>
              </li>
              <li>
                <Link to="/category/io" className="text-gray-300 hover:text-white">
                  IO Games
                </Link>
              </li>
              <li>
                <Link to="/category/multiplayer" className="text-gray-300 hover:text-white">
                  Multiplayer Games
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="mb-4 text-lg font-semibold text-white">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/" className="text-gray-300 hover:text-white">
                  Home
                </Link>
              </li>
              <li>
                <Link to="/category/new" className="text-gray-300 hover:text-white">
                  New Games
                </Link>
              </li>
              <li>
                <Link to="/category/popular" className="text-gray-300 hover:text-white">
                  Popular Games
                </Link>
              </li>
              <li>
                <Link to="/crazygames" className="text-gray-300 hover:text-white flex items-center">
                  <img
                    src="https://ext.same-assets.com/2519731525/2563901416.svg"
                    alt="CrazyGames"
                    className="h-4 w-4 mr-2"
                  />
                  <span>CrazyGames</span>
                </Link>
              </li>
              <li>
                <Link to="/favorites" className="text-gray-300 hover:text-white flex items-center">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    viewBox="0 0 24 24"
                    fill="currentColor"
                    className="h-4 w-4 mr-1"
                  >
                    <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" />
                  </svg>
                  <span>My Favorites</span>
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="mb-4 text-lg font-semibold text-white">About</h3>
            <p className="text-gray-300 mb-2">
              Ultimate Unblocked Games is a collection of games from various sources. We've
              compiled them in one place so you can enjoy them without any restrictions.
            </p>
            <p className="text-gray-300">
              Sources include games from <Link to="/crazygames" className="text-blue-300 hover:text-blue-200">CrazyGames</Link> and other popular gaming platforms.
            </p>
          </div>
        </div>

        <div className="mt-10 border-t border-gray-700 pt-6 text-center text-gray-400">
          <p>&copy; {currentYear} Ultimate Unblocked Games. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
