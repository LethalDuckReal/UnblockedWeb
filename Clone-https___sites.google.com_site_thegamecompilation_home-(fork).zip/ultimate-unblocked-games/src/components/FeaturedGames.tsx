import { FC } from 'react';
import { Link } from 'react-router-dom';
import { gameData } from '../data/games';

const FeaturedGames: FC = () => {
  // Get featured games
  const featuredGames = gameData.filter(game => game.isFeatured).slice(0, 3);

  if (featuredGames.length === 0) {
    return null;
  }

  return (
    <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
      {featuredGames.map(game => (
        <div
          key={game.id}
          className="relative rounded-xl shadow-lg bg-gradient-to-br from-blue-500 to-purple-600 text-white overflow-hidden"
        >
          <div className="p-6">
            <h3 className="text-xl font-bold mb-2">{game.title}</h3>
            <p className="text-sm opacity-90 line-clamp-2 mb-4">
              {game.description || `Play ${game.title} now!`}
            </p>
            <div className="flex flex-wrap gap-2 mb-4">
              {game.categories.map(category => (
                <span key={category} className="text-xs bg-white/20 px-2 py-1 rounded-full">
                  {category}
                </span>
              ))}
            </div>
            <div className="flex items-center space-x-2">
              <Link
                to={`/game/${game.id}`}
                className="inline-block rounded bg-white/20 hover:bg-white/30 px-4 py-2 text-sm font-medium transition-colors"
              >
                Game Details
              </Link>
              <Link
                to={`/game/${game.id}?autostart=true`}
                className="inline-block rounded bg-green-500 hover:bg-green-600 px-4 py-2 text-sm font-medium transition-colors"
              >
                Play Now
              </Link>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default FeaturedGames;
