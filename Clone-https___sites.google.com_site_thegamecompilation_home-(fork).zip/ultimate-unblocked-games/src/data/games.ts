// Game data interface
export interface Game {
  id: string;
  title: string;
  description?: string;
  thumbnail: string;
  url?: string;
  categories: string[];
  isNew?: boolean;
  isPopular?: boolean;
  isFeatured?: boolean;
  source?: string; // Add this field to track where the game comes from
}

// Sample game data
export const gameData: Game[] = [
  // Original Games
  {
    id: 'stick-merge',
    title: 'Stick Merge',
    description: 'Merge stickmen and create an army to defeat your enemies.',
    thumbnail: 'https://ext.same-assets.com/2579683849/3982443703.jpeg',
    url: 'https://stick-merge.io/',
    categories: ['Action', 'Strategy'],
    isNew: true,
    isPopular: true,
    isFeatured: true
  },
  {
    id: 'retro-bowl',
    title: 'Retro Bowl',
    description: 'Experience the classic American football gameplay with retro graphics.',
    thumbnail: 'https://ext.same-assets.com/1096094982/526726091.jpeg',
    url: 'https://retro-bowl.netlify.app/',
    categories: ['Sports', 'Arcade'],
    isPopular: true,
    isFeatured: true
  },
  {
    id: 'slope',
    title: 'Slope',
    description: 'Speed down a randomized slope. Test your reflexes in this fast-paced game.',
    thumbnail: 'https://ext.same-assets.com/40817402/3766356502.jpeg',
    url: 'https://slope-game.netlify.app/',
    categories: ['Arcade', 'Racing'],
    isPopular: true
  },
  {
    id: 'cookie-clicker',
    title: 'Cookie Clicker',
    description: 'Click cookies, upgrade your production, and become a cookie billionaire.',
    thumbnail: 'https://ext.same-assets.com/983114664/911618469.jpeg',
    url: 'https://advanced-channeler.02.gz-associates.com/',
    categories: ['Clicker', 'Idle'],
    isPopular: true
  },
  {
    id: 'drift-hunters',
    title: 'Drift Hunters',
    description: 'Master the art of drifting with realistic physics and car customization.',
    thumbnail: 'https://ext.same-assets.com/834908125/2002287899.jpeg',
    url: 'https://webglmath.github.io/drift-hunters/',
    categories: ['Racing', 'Sports'],
    isPopular: true,
    isFeatured: true
  },
  {
    id: 'stickman-hook',
    title: 'Stickman Hook',
    description: 'Swing through challenging levels with a grappling hook.',
    thumbnail: 'https://ext.same-assets.com/1047064619/3326363091.jpeg',
    url: 'https://algebra-solver.github.io/stickman-hook/',
    categories: ['Arcade', 'Action'],
    isNew: true
  },
  {
    id: 'chicken-merge',
    title: 'Chicken Merge',
    description: 'Merge chickens to create bigger and more valuable birds.',
    thumbnail: 'https://ext.same-assets.com/1696311518/4166018400.jpeg',
    url: 'https://chickenmerge.io/',
    categories: ['Puzzle', 'Idle'],
    isNew: true
  },
  {
    id: 'blumgi-slime',
    title: 'Blumgi Slime',
    description: 'Control a slime creature and solve challenging puzzles.',
    thumbnail: 'https://ext.same-assets.com/1128507666/2763424483.jpeg',
    url: 'https://html5.gamedistribution.com/a64644deef9b452ba2a9631c23983f93/',
    categories: ['Puzzle', 'Adventure'],
    isNew: true
  },
  {
    id: 'smash-karts',
    title: 'Smash Karts',
    description: 'Battle against other karts in this action-packed multiplayer game.',
    thumbnail: 'https://ext.same-assets.com/790069179/540028944.jpeg',
    url: 'https://smashkarts.io/',
    categories: ['Racing', 'Battle'],
    isPopular: true
  },
  {
    id: 'amongus',
    title: 'Among Us',
    description: 'Find the impostor among the crew members in this space-themed social deduction game.',
    thumbnail: 'https://ext.same-assets.com/3358987636/1514266384.jpeg',
    url: 'https://play.gamezop.com/among-us-singleplayer/3532',
    categories: ['Strategy', 'Multiplayer'],
    isPopular: true
  },
  {
    id: '1v1-lol',
    title: '1v1.LOL',
    description: 'Build and battle in this 1v1 building game.',
    thumbnail: 'https://ext.same-assets.com/3421861904/2890057211.jpeg',
    url: 'https://1v1lol.io/',
    categories: ['Battle', 'Action'],
    isPopular: true
  },
  {
    id: 'head-soccer-2023',
    title: 'Head Soccer 2023',
    description: 'Score goals with oversized heads in this fun soccer game.',
    thumbnail: 'https://ext.same-assets.com/423002613/2659944406.jpeg',
    url: 'https://webglmath.github.io/head-soccer-2023/',
    categories: ['Sports', '2-player'],
    isNew: true
  },
  {
    id: 'drive-mad',
    title: 'Drive Mad',
    description: 'Drive through crazy tracks and obstacles in this physics-based driving game.',
    thumbnail: 'https://ext.same-assets.com/703901663/772503348.jpeg',
    url: 'https://webglmath.github.io/drive-mad/',
    categories: ['Driving', 'Physics'],
    isNew: true
  },
  {
    id: 'happy-wheels',
    title: 'Happy Wheels',
    description: 'Control various characters through deadly obstacle courses.',
    thumbnail: 'https://ext.same-assets.com/2967348506/1046338676.jpeg',
    url: 'https://happywheels1.io/',
    categories: ['Action', 'Physics'],
    isPopular: true
  },
  {
    id: 'ovo',
    title: 'OvO',
    description: 'Navigate through challenging levels with simple controls but difficult obstacles.',
    thumbnail: 'https://ext.same-assets.com/2700393739/465222939.jpeg',
    url: 'https://dedragames.com/games/ovo/',
    categories: ['Platformer', 'Arcade'],
    isPopular: true
  },
  {
    id: 'friday-night-funkin',
    title: 'Friday Night Funkin',
    description: 'Rhythm game where you battle through rap battles against various characters.',
    thumbnail: 'https://ext.same-assets.com/1297610506/3729211215.jpeg',
    url: 'https://fridaynightfunkin.io/play/',
    categories: ['Rhythm', 'Music'],
    isPopular: true
  },
  {
    id: 'fall-guys',
    title: 'Fall Guys',
    description: 'Compete in crazy obstacle courses against other players.',
    thumbnail: 'https://ext.same-assets.com/3678099920/3428676808.jpeg',
    url: 'https://fallguys-online.io/',
    categories: ['Multiplayer', 'Obstacle'],
    isPopular: true
  },
  {
    id: 'fnaf',
    title: 'Five Nights at Freddy\'s',
    description: 'Survive five nights as a security guard at Freddy Fazbear\'s Pizza.',
    thumbnail: 'https://ext.same-assets.com/1360160266/1255793557.jpeg',
    url: 'https://static.playunblocked.com/2022/02/five-nights-at-freddys/',
    categories: ['Horror', 'Strategy'],
    isPopular: true
  },
  {
    id: 'run-3',
    title: 'Run 3',
    description: 'Navigate through space tunnels with various characters.',
    thumbnail: 'https://ext.same-assets.com/2304216931/1867689048.jpeg',
    url: 'https://ubg77.github.io/game131022/run3/',
    categories: ['Platformer', 'Endless Runner'],
    isPopular: true
  },
  {
    id: 'papas-louie',
    title: 'Papa\'s Louie',
    description: 'Run a busy restaurant and serve customers in this time management game.',
    thumbnail: 'https://ext.same-assets.com/1595294794/1285264117.jpeg',
    url: 'https://www.coolmathgames.com/0-papas-pizzeria',
    categories: ['Simulation', 'Time Management'],
    isPopular: true
  },

  // New Games from Incredible Website
  {
    id: 'tunnel-rush',
    title: 'Tunnel Rush',
    description: 'Speed through a colorful tunnel filled with obstacles that you must dodge.',
    thumbnail: 'https://ext.same-assets.com/1642835349/777392586.jpeg',
    url: 'https://incrediblewebsite.github.io/tunnelrush/',
    categories: ['Arcade', 'Reaction'],
    isNew: true,
    isPopular: true
  },
  {
    id: 'fireboy-and-watergirl',
    title: 'Fireboy and Watergirl',
    description: 'Control both Fireboy and Watergirl simultaneously to solve puzzles and reach the exit.',
    thumbnail: 'https://ext.same-assets.com/3582110482/673309754.jpeg',
    url: 'https://incrediblewebsite.github.io/fbwg/',
    categories: ['Puzzle', '2-player', 'Adventure'],
    isNew: true,
    isFeatured: true
  },
  {
    id: '2048',
    title: '2048',
    description: 'Combine tiles to create the number 2048 in this addictive puzzle game.',
    thumbnail: 'https://ext.same-assets.com/3175487029/4047693255.jpeg',
    url: 'https://incrediblewebsite.github.io/2048/',
    categories: ['Puzzle', 'Strategy'],
    isNew: true
  },
  {
    id: 'geometry-dash',
    title: 'Geometry Dash',
    description: 'Jump and fly your way through multiple levels with great music.',
    thumbnail: 'https://ext.same-assets.com/1845632097/1467553218.jpeg',
    url: 'https://incrediblewebsite.github.io/geometrydash/',
    categories: ['Rhythm', 'Platformer'],
    isNew: true,
    isPopular: true
  },
  {
    id: 'fruit-ninja',
    title: 'Fruit Ninja',
    description: 'Slice fruit, avoid bombs, and become the ultimate fruit ninja.',
    thumbnail: 'https://ext.same-assets.com/4236708635/2583923104.jpeg',
    url: 'https://incrediblewebsite.github.io/fruitninja/',
    categories: ['Arcade', 'Mobile'],
    isNew: true
  },
  {
    id: 'bad-time-simulator',
    title: 'Bad Time Simulator',
    description: 'A challenging boss fight against Sans from Undertale.',
    thumbnail: 'https://ext.same-assets.com/2473068910/2075311483.jpeg',
    url: 'https://incrediblewebsite.github.io/sans/',
    categories: ['RPG', 'Boss Fight'],
    isNew: true
  },
  {
    id: 'super-mario-64',
    title: 'Super Mario 64',
    description: 'Play the classic 3D Mario platformer in your browser.',
    thumbnail: 'https://ext.same-assets.com/1247739086/1683055373.jpeg',
    url: 'https://incrediblewebsite.github.io/sm64/',
    categories: ['Platformer', 'Retro'],
    isNew: true,
    isFeatured: true
  },
  {
    id: 'tetris',
    title: 'Tetris',
    description: 'The classic block-stacking puzzle game that never gets old.',
    thumbnail: 'https://ext.same-assets.com/778564220/2349117596.jpeg',
    url: 'https://incrediblewebsite.github.io/tetris/',
    categories: ['Puzzle', 'Retro'],
    isNew: true
  },
  {
    id: 'flappy-bird',
    title: 'Flappy Bird',
    description: 'Guide the bird through pipes without touching them in this iconic mobile game.',
    thumbnail: 'https://ext.same-assets.com/2364770513/1097503735.jpeg',
    url: 'https://incrediblewebsite.github.io/flappybird/',
    categories: ['Arcade', 'Mobile'],
    isNew: true
  },
  {
    id: 'doom',
    title: 'Doom',
    description: 'Play the legendary first-person shooter that defined a genre.',
    thumbnail: 'https://ext.same-assets.com/3784029175/3257803924.jpeg',
    url: 'https://incrediblewebsite.github.io/doom/',
    categories: ['FPS', 'Retro'],
    isNew: true
  },
  {
    id: 'a-dark-room',
    title: 'A Dark Room',
    description: 'A minimalist text adventure game with deep gameplay and story.',
    thumbnail: 'https://ext.same-assets.com/2689354071/2930384521.jpeg',
    url: 'https://incrediblewebsite.github.io/adarkroom/',
    categories: ['Text Adventure', 'Strategy'],
    isNew: true
  },
  {
    id: 'minecraft-classic',
    title: 'Minecraft Classic',
    description: 'The original browser version of Minecraft with creative mode.',
    thumbnail: 'https://ext.same-assets.com/1535762846/1240118735.jpeg',
    url: 'https://incrediblewebsite.github.io/minecraftclassic/',
    categories: ['Sandbox', 'Building'],
    isNew: true,
    isPopular: true
  },
  {
    id: 'cut-the-rope',
    title: 'Cut the Rope',
    description: 'Cut ropes to feed candy to Om Nom in this physics-based puzzle game.',
    thumbnail: 'https://ext.same-assets.com/1173608249/2301491582.jpeg',
    url: 'https://incrediblewebsite.github.io/ctr/',
    categories: ['Puzzle', 'Physics'],
    isNew: true
  },
  {
    id: 'celeste-classic',
    title: 'Celeste Classic',
    description: 'The original version of the acclaimed platformer Celeste.',
    thumbnail: 'https://ext.same-assets.com/2903758102/984639173.jpeg',
    url: 'https://incrediblewebsite.github.io/celeste/',
    categories: ['Platformer', 'Pixel Art'],
    isNew: true
  },
  {
    id: 'hexgl',
    title: 'HexGL',
    description: 'A futuristic, fast-paced racing game with stunning visuals.',
    thumbnail: 'https://ext.same-assets.com/1728349570/3854907642.jpeg',
    url: 'https://incrediblewebsite.github.io/hexgl/',
    categories: ['Racing', '3D'],
    isNew: true
  },

  // CrazyGames Collection
  {
    id: 'bloxd-io',
    title: 'Bloxd.io',
    description: 'Build, jump, and race against other players in this multiplayer block game.',
    thumbnail: 'https://ext.same-assets.com/3844154106/1955730066.jpeg',
    url: 'https://www.crazygames.com/game/bloxdhop-io',
    categories: ['Multiplayer', 'Platformer', 'Building'],
    isNew: true,
    isPopular: true,
    isFeatured: true,
    source: 'crazygames'
  },
  {
    id: 'shell-shockers',
    title: 'Shell Shockers',
    description: 'First-person shooter where you play as armed eggs in intense multiplayer battles.',
    thumbnail: 'https://ext.same-assets.com/3844154106/4063479587.jpeg',
    url: 'https://www.crazygames.com/game/shellshockersio',
    categories: ['FPS', 'Multiplayer', 'Action'],
    isNew: true,
    isPopular: true,
    source: 'crazygames'
  },
  {
    id: 'cubes-2048',
    title: 'Cubes 2048',
    description: 'Combine equal-number cubes to reach 2048 in this 3D version of the classic puzzle game.',
    thumbnail: 'https://ext.same-assets.com/3844154106/3337015764.jpeg',
    url: 'https://www.crazygames.com/game/cubes-2048-io',
    categories: ['Puzzle', 'Strategy'],
    isNew: true,
    source: 'crazygames'
  },
  {
    id: 'smash-karts-cg',
    title: 'Smash Karts',
    description: 'Battle with karts in this multiplayer racing game with weapons and power-ups.',
    thumbnail: 'https://ext.same-assets.com/3844154106/2594881173.jpeg',
    url: 'https://www.crazygames.com/game/smash-karts',
    categories: ['Racing', 'Battle', 'Multiplayer'],
    isPopular: true,
    source: 'crazygames'
  },
  {
    id: 'paper-io-2',
    title: 'Paper.io 2',
    description: 'Conquer territory on the map while avoiding other players in this addictive io game.',
    thumbnail: 'https://ext.same-assets.com/3844154106/1034660157.jpeg',
    url: 'https://www.crazygames.com/game/paper-io-2',
    categories: ['IO', 'Strategy', 'Multiplayer'],
    isPopular: true,
    source: 'crazygames'
  },
  {
    id: 'basketball-stars',
    title: 'Basketball Stars',
    description: 'Play fast-paced basketball matches in 1v1 or 2-player mode.',
    thumbnail: 'https://ext.same-assets.com/3844154106/2539587851.jpeg',
    url: 'https://www.crazygames.com/game/basketball-stars',
    categories: ['Sports', '2-player'],
    isPopular: true,
    source: 'crazygames'
  },
  {
    id: 'voxiom-io',
    title: 'Voxiom.io',
    description: 'Build, craft, and shoot in this Minecraft-inspired multiplayer FPS game.',
    thumbnail: 'https://ext.same-assets.com/3844154106/4119055891.jpeg',
    url: 'https://www.crazygames.com/game/voxiom-io',
    categories: ['FPS', 'Building', 'IO'],
    isNew: true,
    source: 'crazygames'
  },
  {
    id: 'rocket-bot-royale',
    title: 'Rocket Bot Royale',
    description: 'Battle with rockets in this 2D battle royale game with physics-based gameplay.',
    thumbnail: 'https://imgs.crazygames.com/games/rocket-bot-royale/cover_16x9-1732723484943.png',
    url: 'https://www.crazygames.com/game/rocket-bot-royale',
    categories: ['Battle Royale', 'Action'],
    isNew: true,
    source: 'crazygames'
  },
  {
    id: 'agar-io',
    title: 'Agar.io',
    description: 'Grow your cell by consuming smaller players while avoiding larger ones in this classic IO game.',
    thumbnail: 'https://imgs.crazygames.com/agario/20230719092731/agario-cover',
    url: 'https://www.crazygames.com/game/agario',
    categories: ['IO', 'Multiplayer'],
    isPopular: true,
    source: 'crazygames'
  },
  {
    id: 'kingdom-solitaire',
    title: 'Kingdom Solitaire',
    description: 'A medieval-themed solitaire game with beautiful graphics and addictive gameplay.',
    thumbnail: 'https://ext.same-assets.com/3844154106/3353479808.jpeg',
    url: 'https://www.crazygames.com/game/kingdom-solitaire',
    categories: ['Card', 'Puzzle'],
    isFeatured: true,
    source: 'crazygames'
  },
  {
    id: 'draw-climber',
    title: 'Draw Climber',
    description: 'Draw legs for your character to overcome obstacles and reach the finish line.',
    thumbnail: 'https://ext.same-assets.com/3844154106/885187664.jpeg',
    url: 'https://www.crazygames.com/game/draw-climber',
    categories: ['Drawing', 'Platformer'],
    isNew: true,
    source: 'crazygames'
  },
  {
    id: 'mini-giants-io',
    title: 'MiniGiants.io',
    description: 'Grow from a tiny character to a giant by collecting gems and defeating other players.',
    thumbnail: 'https://imgs.crazygames.com/games/minigiants-io/cover_16x9-1732723093116.png',
    url: 'https://www.crazygames.com/game/minigiants-io',
    categories: ['IO', 'Multiplayer'],
    isNew: true,
    source: 'crazygames'
  },
  {
    id: 'skribbl-io',
    title: 'Skribbl.io',
    description: 'Draw and guess words in this fun multiplayer drawing game.',
    thumbnail: 'https://imgs.crazygames.com/skribblio.png',
    url: 'https://www.crazygames.com/game/skribblio',
    categories: ['Drawing', 'Multiplayer'],
    isPopular: true,
    source: 'crazygames'
  },
  {
    id: 'word-wipe',
    title: 'Word Wipe',
    description: 'Find and remove words from the grid to clear the board in this word puzzle game.',
    thumbnail: 'https://imgs.crazygames.com/games/word-wipe/cover_16x9-1707829913887.png',
    url: 'https://www.crazygames.com/game/word-wipe',
    categories: ['Word', 'Puzzle'],
    isNew: true,
    source: 'crazygames'
  },
  {
    id: 'uno-online',
    title: 'UNO Online',
    description: 'Play the classic card game UNO against other players or the computer.',
    thumbnail: 'https://imgs.crazygames.com/games/card-party/cover_16x9-1708444731433.png',
    url: 'https://www.crazygames.com/game/card-party',
    categories: ['Card', 'Multiplayer'],
    isFeatured: true,
    source: 'crazygames'
  }
];
