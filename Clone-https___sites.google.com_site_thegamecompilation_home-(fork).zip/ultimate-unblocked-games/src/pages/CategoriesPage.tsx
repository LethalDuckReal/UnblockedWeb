import { FC } from 'react';
import { useParams } from 'react-router-dom';
import Layout from '../components/Layout';
import GameGrid from '../components/GameGrid';
import AlphabetLinks from '../components/AlphabetLinks';

const CategoriesPage: FC = () => {
  const { categoryId } = useParams<{ categoryId: string }>();

  // For a real app, this would be fetched from an API
  const categories = {
    'action': 'Action Games',
    'arcade': 'Arcade Games',
    'io': 'IO Games',
    'shooting': 'Shooting Games',
    'puzzle': 'Puzzle Games',
    'sports': 'Sports Games',
    'racing': 'Racing Games',
    'strategy': 'Strategy Games',
    '2-player': '2 Player Games',
    'clicker': 'Clicker Games',
    'driving': 'Driving Games',
    'new': 'New Games',
    'popular': 'Popular Games',
    'hot': 'Hot Games',
  };

  // Handle letter categories
  let pageTitle = '';

  if (categoryId?.startsWith('letter-')) {
    const letter = categoryId.replace('letter-', '').toUpperCase();
    pageTitle = letter === '0-9' ? 'Games 0-9' : `Games Starting With ${letter}`;
  } else {
    pageTitle = categoryId ? categories[categoryId as keyof typeof categories] || categoryId.replace(/-/g, ' ') : '';
    if (pageTitle && !pageTitle.toLowerCase().includes('games')) {
      pageTitle += ' Games';
    }
  }

  return (
    <Layout>
      <div className="container-custom py-6">
        <AlphabetLinks />

        <h1 className="mb-8 text-center text-3xl font-bold text-gray-800">
          {pageTitle}
        </h1>

        <GameGrid category={categoryId || ''} />
      </div>
    </Layout>
  );
};

export default CategoriesPage;
