import { FC, useEffect, useState, useRef } from 'react';
import { useParams, useNavigate, useLocation } from 'react-router-dom';
import Layout from '../components/Layout';
import RatingSystem from '../components/RatingSystem';
import FavoriteButton from '../components/FavoriteButton';
import { gameData, Game } from '../data/games';

const GamePage: FC = () => {
  const { gameId } = useParams<{ gameId: string }>();
  const navigate = useNavigate();
  const location = useLocation();
  const [isLoading, setIsLoading] = useState(true);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const gameContainerRef = useRef<HTMLDivElement>(null);

  // Find the game data based on the ID
  const game = gameData.find(g => g.id === gameId);

  // Handle fullscreen mode with escape key
  useEffect(() => {
    const handleEscapeKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape' && isFullscreen) {
        setIsFullscreen(false);
      }
    };

    document.addEventListener('keydown', handleEscapeKey);
    return () => {
      document.removeEventListener('keydown', handleEscapeKey);
    };
  }, [isFullscreen]);

  // Handle autostart parameter from URL
  useEffect(() => {
    // Safely extract the autostart parameter
    const params = new URLSearchParams(location.search);
    const autostart = params.get('autostart') === 'true';

    if (autostart) {
      setIsLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleIframeLoad = () => {
    setIsLoading(false);
  };

  // Store play history
  useEffect(() => {
    if (!game) return;

    // Get existing play history from localStorage
    const playHistoryRaw = localStorage.getItem('playHistory');
    const playHistory = playHistoryRaw ? JSON.parse(playHistoryRaw) : [];

    // Remove current game from history if it exists
    const filteredHistory = playHistory.filter((id: string) => id !== game.id);

    // Add current game to the beginning of the history
    const newHistory = [game.id, ...filteredHistory].slice(0, 20); // Keep only 20 most recent

    // Update localStorage
    localStorage.setItem('playHistory', JSON.stringify(newHistory));

    // Dispatch a custom event to notify other components about the change
    window.dispatchEvent(new Event('storage'));
  }, [game]);

  const renderGameSource = (game: Game) => {
    if (!game.source) return null;

    if (game.source === 'crazygames') {
      return (
        <div className="mt-4 flex items-center gap-2">
          <span className="text-sm text-gray-500">Provided by:</span>
          <a
            href="https://www.crazygames.com/"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1"
          >
            <img
              src="https://ext.same-assets.com/2519731525/2563901416.svg"
              alt="CrazyGames"
              className="h-6"
            />
            <span className="text-sm font-semibold">CrazyGames</span>
          </a>
        </div>
      );
    }

    if (game.source === 'incredible') {
      return (
        <div className="mt-4 flex items-center gap-2">
          <span className="text-sm text-gray-500">Provided by:</span>
          <a
            href="https://incrediblewebsite.github.io/"
            target="_blank"
            rel="noopener noreferrer"
            className="text-sm font-semibold text-blue-600 hover:text-blue-800"
          >
            Incredible Website
          </a>
        </div>
      );
    }

    return null;
  };

  if (!game) {
    return (
      <Layout>
        <div className="container-custom py-6 text-center">
          <h1 className="mb-4 text-2xl font-bold text-gray-800">Game Not Found</h1>
          <p className="mb-6 text-lg text-gray-600">
            Sorry, we couldn't find the game you're looking for. It may have been removed or the URL is incorrect.
          </p>
          <button
            onClick={() => navigate('/')}
            className="rounded-md bg-blue-500 px-4 py-2 text-white hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
          >
            Back to Home
          </button>
        </div>
      </Layout>
    );
  }

  const gameUrl = game.url || 'https://www.addictinggames.com/embed/html5-games/';

  return (
    <Layout>
      <div className="container-custom py-6">
        <div className="mb-6 flex items-center justify-between">
          <h1 className="text-3xl font-bold text-gray-800">{game.title}</h1>

          <div className="flex items-center space-x-2">
            <button
              onClick={() => setIsFullscreen(!isFullscreen)}
              className="rounded-md bg-blue-500 px-4 py-2 text-white hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
            >
              {isFullscreen ? 'Exit Fullscreen' : 'Fullscreen'}
            </button>
            <FavoriteButton gameId={game.id} />
          </div>
        </div>

        <div className="mb-8 grid grid-cols-1 gap-6 lg:grid-cols-3">
          <div className="lg:col-span-2">
            <div
              ref={gameContainerRef}
              className={`relative aspect-video w-full overflow-hidden rounded-lg border border-gray-200 bg-gray-100 ${isFullscreen ? 'fixed inset-0 z-50 h-screen w-screen rounded-none border-0' : ''}`}
            >
              {/* Game loading state */}
              {isLoading && (
                <div className="absolute inset-0 flex flex-col items-center justify-center bg-gray-100">
                  <div className="mb-3 h-10 w-10 animate-spin rounded-full border-4 border-blue-500 border-t-transparent"></div>
                  <p className="text-gray-600">Loading game...</p>
                </div>
              )}

              {/* Game iframe */}
              <iframe
                ref={iframeRef}
                src={gameUrl}
                title={game.title}
                className="h-full w-full"
                style={{ display: isLoading ? 'none' : 'block' }}
                onLoad={handleIframeLoad}
                allowFullScreen
                allow="fullscreen"
              ></iframe>

              {/* Fullscreen exit button - more visible when in fullscreen */}
              {isFullscreen && (
                <button
                  onClick={() => setIsFullscreen(false)}
                  className="absolute right-4 top-4 rounded-full bg-black bg-opacity-50 p-2 text-white hover:bg-opacity-70 focus:outline-none"
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-6 w-6"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              )}
            </div>
          </div>

          <div>
            <div className="rounded-lg bg-white p-6 shadow-md">
              <h2 className="mb-3 text-xl font-bold text-gray-800">About {game.title}</h2>
              <p className="mb-4 text-gray-600">{game.description}</p>

              <div className="mb-4">
                <h3 className="mb-2 font-semibold text-gray-700">Categories</h3>
                <div className="flex flex-wrap gap-2">
                  {game.categories.map(category => (
                    <span
                      key={category}
                      className="rounded-full bg-blue-100 px-3 py-1 text-xs font-medium text-blue-800"
                    >
                      {category}
                    </span>
                  ))}
                </div>
              </div>

              <RatingSystem gameId={game.id} />

              {renderGameSource(game)}
            </div>
          </div>
        </div>

        <div className="mt-8">
          <h2 className="mb-4 text-2xl font-bold text-gray-800">How to Play</h2>
          <div className="rounded-lg bg-white p-6 shadow-md">
            <p className="text-lg text-gray-600">
              Use your keyboard and mouse to control the game. Click inside the game area if the controls aren't
              responding. For the best experience, try fullscreen mode!
            </p>

            {game.isNew && (
              <div className="mt-4 rounded-md bg-green-100 p-3 text-green-800">
                <span className="font-semibold">New Game!</span> This game was recently added to our collection.
              </div>
            )}

            {game.isPopular && (
              <div className="mt-4 rounded-md bg-yellow-100 p-3 text-yellow-800">
                <span className="font-semibold">Popular Game!</span> This is one of our most played games.
              </div>
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default GamePage;
