import { FC, useEffect, useState } from 'react';
import Layout from '../components/Layout';
import GameGrid from '../components/GameGrid';
import FeaturedGames from '../components/FeaturedGames';
import AlphabetLinks from '../components/AlphabetLinks';
import GameRecommendations from '../components/GameRecommendations';
import RecentlyPlayed from '../components/RecentlyPlayed';

const HomePage: FC = () => {
  const [hasPlayHistory, setHasPlayHistory] = useState(false);

  // Check if user has play history
  useEffect(() => {
    const checkPlayHistory = () => {
      const playHistory = localStorage.getItem('playHistory');
      setHasPlayHistory(!!playHistory && JSON.parse(playHistory).length > 0);
    };

    checkPlayHistory();

    // Listen for storage events to update in real-time
    window.addEventListener('storage', checkPlayHistory);

    return () => {
      window.removeEventListener('storage', checkPlayHistory);
    };
  }, []);

  return (
    <Layout>
      <div className="container-custom py-6">
        <h1 className="mb-6 text-center text-4xl font-bold text-gray-800">Ultimate Unblocked Games</h1>

        <AlphabetLinks />

        <section className="mb-12">
          <h2 className="section-title">Featured Games</h2>
          <FeaturedGames />
        </section>

        {/* Recently Played Section */}
        {hasPlayHistory && (
          <section className="mb-12">
            <RecentlyPlayed limit={5} />
          </section>
        )}

        {/* CrazyGames Section */}
        <section className="mb-12 rounded-lg overflow-hidden">
          <div className="bg-[#0f1018] p-6 text-white">
            <div className="flex items-center gap-3 mb-4">
              <img
                src="https://ext.same-assets.com/2519731525/2563901416.svg"
                alt="CrazyGames Logo"
                className="h-8"
              />
              <h2 className="text-2xl font-bold">CrazyGames Collection</h2>
            </div>
            <div className="mb-4">
              <p className="text-gray-300">
                We've added awesome games from CrazyGames! Enjoy popular titles like Bloxd.io, Shell Shockers,
                and more. Play these high-quality browser games without any installation.
              </p>
            </div>
            <div className="bg-[#0f1018]">
              <GameGrid category="crazygames" limit={10} />
            </div>
            <div className="mt-4 flex justify-end">
              <a
                href="https://www.crazygames.com/"
                target="_blank"
                rel="noopener noreferrer"
                className="text-blue-400 hover:text-blue-300 text-sm flex items-center gap-1"
              >
                More games on CrazyGames
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
                </svg>
              </a>
            </div>
          </div>
        </section>

        <section className="mb-12">
          <h2 className="section-title">Incredible Website Games</h2>
          <div className="mb-4">
            <p className="text-gray-600">
              We've just added these awesome games from Incredible Website! Check them out now.
            </p>
          </div>
          <GameGrid category="incredible" limit={10} />
        </section>

        {hasPlayHistory && (
          <section className="mb-12">
            <GameRecommendations limit={6} />
          </section>
        )}

        <section className="mb-12">
          <h2 className="section-title">New Unblocked Games</h2>
          <GameGrid category="new" limit={10} />
        </section>

        <section className="mb-12">
          <h2 className="section-title">Hot Unblocked Games</h2>
          <GameGrid category="hot" limit={10} />
        </section>

        <div className="mt-16 rounded-lg bg-white p-6 shadow-md">
          <h2 className="mb-4 text-2xl font-bold text-gray-800">About Ultimate Unblocked Games</h2>
          <p className="text-lg text-gray-600 leading-relaxed">
            Hi there! You probably know the feeling of boredom in class at school or college, but we have a solution for you!
            Play the most popular Unblocked Games on our website and forget about sadness. We have compiled for you a large
            collection of online games from the most popular Google Sites including many Flash games. Yes, we were not
            mistaken! We were able to restore the work of many old Flash games that stopped working after turning off Flash
            technology in browsers.
          </p>
          <p className="mt-4 text-lg text-gray-600 leading-relaxed">
            You don't need to install anything to start the game. You just need to have a computer
            on Windows, Chrome OS, Mac OS and a modern browser (for example, Google Chrome or Mozilla Firefox).
            In addition to popular games, we also post new HTML5 games on the site several times a week.
            Bookmark us and tell your friends about us!
          </p>
        </div>
      </div>
    </Layout>
  );
};

export default HomePage;
