import { FC, useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import Layout from '../components/Layout';
import { gameData, Game } from '../data/games';
import GameRecommendations from '../components/GameRecommendations';

const FavoritesPage: FC = () => {
  const [favoriteGames, setFavoriteGames] = useState<Game[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadFavorites = () => {
      const favorites = JSON.parse(localStorage.getItem('favorites') || '[]');
      const games = gameData.filter(game => favorites.includes(game.id));
      setFavoriteGames(games);
      setLoading(false);
    };

    loadFavorites();

    // Add event listener for storage changes (in case user adds/removes favorites in another tab)
    window.addEventListener('storage', loadFavorites);

    return () => {
      window.removeEventListener('storage', loadFavorites);
    };
  }, []);

  const removeFavorite = (gameId: string) => {
    const favorites = JSON.parse(localStorage.getItem('favorites') || '[]');
    const newFavorites = favorites.filter((id: string) => id !== gameId);
    localStorage.setItem('favorites', JSON.stringify(newFavorites));

    // Update state
    setFavoriteGames(favoriteGames.filter(game => game.id !== gameId));

    // Dispatch storage event to notify other tabs
    window.dispatchEvent(new Event('storage'));
  };

  return (
    <Layout>
      <div className="container-custom py-8">
        <h1 className="mb-6 text-center text-3xl font-bold text-gray-800">My Favorites</h1>

        {loading ? (
          <div className="flex justify-center py-8">
            <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-blue-600 border-t-transparent"></div>
          </div>
        ) : (
          <div className="mb-12">
            {favoriteGames.length > 0 ? (
              <div className="grid grid-cols-2 gap-6 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
                {favoriteGames.map(game => (
                  <div key={game.id} className="game-card relative">
                    <button
                      onClick={() => removeFavorite(game.id)}
                      className="absolute right-2 top-2 z-10 flex h-8 w-8 items-center justify-center rounded-full bg-white/80 text-red-500 hover:bg-white"
                      aria-label="Remove from favorites"
                    >
                      <svg className="h-5 w-5 fill-current" viewBox="0 0 24 24">
                        <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" />
                      </svg>
                    </button>
                    <Link to={`/game/${game.id}`} className="block">
                      <div className="aspect-square overflow-hidden">
                        <img
                          src={game.thumbnail}
                          alt={game.title}
                          className="h-full w-full object-cover transition-transform hover:scale-110"
                          loading="lazy"
                        />
                      </div>
                      <div className="bg-white p-3">
                        <h3 className="font-medium text-gray-900 truncate">{game.title}</h3>
                        <p className="mt-1 text-sm text-gray-500 truncate">{game.categories[0]}</p>
                      </div>
                    </Link>
                  </div>
                ))}
              </div>
            ) : (
              <div className="bg-white rounded-lg shadow-md p-8 text-center">
                <svg
                  className="w-16 h-16 text-gray-300 mx-auto mb-4"
                  viewBox="0 0 24 24"
                  fill="currentColor"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" />
                </svg>
                <h2 className="text-xl font-semibold text-gray-700 mb-2">No Favorites Yet</h2>
                <p className="text-gray-500 mb-6">
                  You haven't added any games to your favorites yet. Browse games and click the heart icon to add them here.
                </p>
                <Link
                  to="/"
                  className="inline-block bg-blue-600 text-white px-6 py-2 rounded-md hover:bg-blue-700 transition-colors"
                >
                  Browse Games
                </Link>
              </div>
            )}
          </div>
        )}

        {!loading && (
          <div className="mt-12">
            <GameRecommendations limit={10} />
          </div>
        )}
      </div>
    </Layout>
  );
};

export default FavoritesPage;
