import { FC, useContext, useEffect, useState } from 'react';
import Layout from '../components/Layout';
import GameGrid from '../components/GameGrid';
import { ThemeContext } from '../context/ThemeContext';
import { gameData, Game } from '../data/games';

interface GameCategory {
  name: string;
  games: Game[];
}

const CrazyGamesPage: FC = () => {
  const { darkMode } = useContext(ThemeContext);
  const [categories, setCategories] = useState<GameCategory[]>([]);

  useEffect(() => {
    // Get all CrazyGames
    const crazyGames = gameData.filter(game => game.source === 'crazygames');

    // Get all unique categories
    const allCategories = new Set<string>();
    crazyGames.forEach(game => {
      game.categories.forEach(category => {
        allCategories.add(category);
      });
    });

    // Create category objects with games
    const categoryObjects: GameCategory[] = Array.from(allCategories).map(category => {
      return {
        name: category,
        games: crazyGames.filter(game => game.categories.includes(category))
      };
    });

    // Sort categories by number of games (descending)
    categoryObjects.sort((a, b) => b.games.length - a.games.length);

    // Only show categories with at least 2 games
    setCategories(categoryObjects.filter(cat => cat.games.length >= 2));
  }, []);

  return (
    <Layout>
      <div className={`py-8 ${darkMode ? 'bg-gray-900 text-white' : 'bg-white text-gray-800'}`}>
        <div className="container-custom">
          <div className="mb-8 flex flex-col items-center text-center">
            <div className="flex items-center gap-2">
              <img
                src="https://ext.same-assets.com/2519731525/2563901416.svg"
                alt="CrazyGames Logo"
                className="h-10"
              />
              <h1 className={`text-3xl font-bold ${darkMode ? 'text-white' : 'text-gray-800'}`}>
                CrazyGames Collection
              </h1>
            </div>
            <p className={`mt-4 max-w-3xl ${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>
              Explore our collection of awesome games from CrazyGames! Play popular titles like Bloxd.io, Shell Shockers,
              and more - all without any installation or downloads.
            </p>
          </div>

          <div className="mb-10 grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
            <div className={`rounded-lg ${darkMode ? 'bg-gray-800' : 'bg-blue-50'} p-5`}>
              <div className="flex items-center gap-2">
                <svg
                  className={`h-6 w-6 ${darkMode ? 'text-blue-400' : 'text-blue-500'}`}
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"
                  />
                </svg>
                <h3 className={`text-xl font-semibold ${darkMode ? 'text-white' : 'text-gray-800'}`}>No Installation Required</h3>
              </div>
              <p className={`mt-2 ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                Play instantly in your browser without downloading anything.
              </p>
            </div>

            <div className={`rounded-lg ${darkMode ? 'bg-gray-800' : 'bg-blue-50'} p-5`}>
              <div className="flex items-center gap-2">
                <svg
                  className={`h-6 w-6 ${darkMode ? 'text-blue-400' : 'text-blue-500'}`}
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
                  />
                </svg>
                <h3 className={`text-xl font-semibold ${darkMode ? 'text-white' : 'text-gray-800'}`}>Daily Updates</h3>
              </div>
              <p className={`mt-2 ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                We regularly add new games to our collection to keep the fun fresh.
              </p>
            </div>

            <div className={`rounded-lg ${darkMode ? 'bg-gray-800' : 'bg-blue-50'} p-5`}>
              <div className="flex items-center gap-2">
                <svg
                  className={`h-6 w-6 ${darkMode ? 'text-blue-400' : 'text-blue-500'}`}
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"
                  />
                </svg>
                <h3 className={`text-xl font-semibold ${darkMode ? 'text-white' : 'text-gray-800'}`}>Multiplayer Fun</h3>
              </div>
              <p className={`mt-2 ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                Many games feature multiplayer modes to enjoy with friends.
              </p>
            </div>
          </div>

          <div className="mb-8">
            <h2 className={`mb-6 text-2xl font-bold ${darkMode ? 'text-white' : 'text-gray-800'}`}>All CrazyGames</h2>
            <GameGrid category="crazygames" />
          </div>

          {categories.map(category => (
            <div key={category.name} className="mb-8">
              <h2 className={`mb-4 text-xl font-semibold ${darkMode ? 'text-white' : 'text-gray-800'}`}>
                {category.name} Games ({category.games.length})
              </h2>
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
                {category.games.map(game => (
                  <div key={game.id}>
                    <a
                      href={`/game/${game.id}`}
                      className={`game-tab ${darkMode ? 'crazygames-dark' : ''}`}
                    >
                      <h3 className="title">{game.title}</h3>
                      <p className="category">{game.categories[0]}</p>
                      <span className="play-button">Play</span>
                    </a>
                  </div>
                ))}
              </div>
            </div>
          ))}

          <div className={`mt-8 rounded-lg ${darkMode ? 'bg-gray-800' : 'bg-blue-50'} p-6`}>
            <h2 className={`mb-3 text-2xl font-semibold ${darkMode ? 'text-white' : 'text-gray-800'}`}>
              About CrazyGames
            </h2>
            <p className={`mb-4 ${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>
              CrazyGames is a browser gaming platform that offers free online games. The platform was founded in 2013
              and has since grown to offer thousands of games across various categories such as action, puzzle, sports,
              and multiplayer. All games are thoroughly tested and only high-quality, fun games make it to the platform.
            </p>
            <div className="flex justify-end">
              <a
                href="https://www.crazygames.com/"
                target="_blank"
                rel="noopener noreferrer"
                className={`flex items-center gap-1 ${darkMode ? 'text-blue-400 hover:text-blue-300' : 'text-blue-600 hover:text-blue-700'}`}
              >
                Visit CrazyGames
                <svg
                  className="ml-1 h-4 w-4"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"
                  />
                </svg>
              </a>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default CrazyGamesPage;
