import { FC, ReactNode, useContext } from 'react';
import Header from './Header';
import Footer from './Footer';
import { ThemeContext } from '../context/ThemeContext';

interface LayoutProps {
  children: ReactNode;
}

const Layout: FC<LayoutProps> = ({ children }) => {
  const { darkMode } = useContext(ThemeContext);

  return (
    <div className={`flex min-h-screen flex-col ${darkMode ? 'bg-gray-900 text-white' : 'bg-white text-gray-800'} transition-colors duration-200`}>
      <Header />
      <main className="flex-1">{children}</main>
      <Footer />
    </div>
  );
};

export default Layout;
