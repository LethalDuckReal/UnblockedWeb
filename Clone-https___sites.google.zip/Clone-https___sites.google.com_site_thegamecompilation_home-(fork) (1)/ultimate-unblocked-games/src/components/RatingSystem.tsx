import { FC, useState, useEffect } from 'react';

interface RatingSystemProps {
  gameId: string;
}

interface Rating {
  value: number;
  count: number;
}

const RatingSystem: FC<RatingSystemProps> = ({ gameId }) => {
  const [userRating, setUserRating] = useState<number | null>(null);
  const [averageRating, setAverageRating] = useState<number>(0);
  const [ratingCount, setRatingCount] = useState<number>(0);
  const [hoverRating, setHoverRating] = useState<number | null>(null);

  // Load existing ratings from localStorage
  useEffect(() => {
    const allRatings = JSON.parse(localStorage.getItem('gameRatings') || '{}');
    const gameRatings = allRatings[gameId] || { value: 0, count: 0 };

    setAverageRating(gameRatings.value);
    setRatingCount(gameRatings.count);

    // Load user's own rating for this game if they've rated before
    const userRatings = JSON.parse(localStorage.getItem('userRatings') || '{}');
    if (userRatings[gameId]) {
      setUserRating(userRatings[gameId]);
    }
  }, [gameId]);

  const handleRating = (rating: number) => {
    // Save user's new rating
    const userRatings = JSON.parse(localStorage.getItem('userRatings') || '{}');
    const oldUserRating = userRatings[gameId] || null;
    userRatings[gameId] = rating;
    localStorage.setItem('userRatings', JSON.stringify(userRatings));

    // Update the average rating
    const allRatings = JSON.parse(localStorage.getItem('gameRatings') || '{}');
    const gameRatings = allRatings[gameId] || { value: 0, count: 0 };

    if (oldUserRating) {
      // User is changing their rating
      const totalValue = gameRatings.value * gameRatings.count;
      const newTotal = totalValue - oldUserRating + rating;
      gameRatings.value = newTotal / gameRatings.count;
    } else {
      // User is rating for the first time
      const totalValue = gameRatings.value * gameRatings.count;
      gameRatings.count += 1;
      gameRatings.value = (totalValue + rating) / gameRatings.count;
    }

    allRatings[gameId] = gameRatings;
    localStorage.setItem('gameRatings', JSON.stringify(allRatings));

    // Update state
    setUserRating(rating);
    setAverageRating(gameRatings.value);
    setRatingCount(gameRatings.count);
  };

  const stars = [1, 2, 3, 4, 5];

  return (
    <div className="py-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between">
        <div className="mb-2 sm:mb-0">
          <h3 className="text-lg font-semibold mb-1">Game Rating</h3>
          <div className="flex items-center">
            <div className="flex">
              {stars.map((star) => (
                <svg
                  key={star}
                  className="w-5 h-5 text-yellow-400 fill-current"
                  viewBox="0 0 24 24"
                >
                  <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" />
                </svg>
              ))}
            </div>
            <span className="ml-2 text-gray-600">
              {averageRating.toFixed(1)} ({ratingCount} {ratingCount === 1 ? 'rating' : 'ratings'})
            </span>
          </div>
        </div>

        <div>
          <h3 className="text-sm font-medium text-gray-700 mb-1">Rate this game:</h3>
          <div className="flex">
            {stars.map((star) => (
              <button
                key={star}
                type="button"
                onClick={() => handleRating(star)}
                onMouseEnter={() => setHoverRating(star)}
                onMouseLeave={() => setHoverRating(null)}
                className="p-1 focus:outline-none focus:ring-0"
              >
                <svg
                  className={`w-6 h-6 ${
                    (hoverRating !== null ? star <= hoverRating : star <= (userRating || 0))
                      ? 'text-yellow-400'
                      : 'text-gray-300'
                  } fill-current`}
                  viewBox="0 0 24 24"
                >
                  <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" />
                </svg>
              </button>
            ))}
          </div>
        </div>
      </div>

      {userRating && (
        <div className="mt-2 text-sm text-blue-600">
          Thanks for rating this game!
        </div>
      )}
    </div>
  );
};

export default RatingSystem;
