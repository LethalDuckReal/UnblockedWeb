import { FC } from 'react';
import { Link } from 'react-router-dom';
import { gameData } from '../data/games';

interface GameGridProps {
  category: string;
  limit?: number;
}

const GameGrid: FC<GameGridProps> = ({ category, limit }) => {
  // Filter games by category
  let games = gameData;

  if (category === 'new') {
    games = gameData.filter(game => game.isNew);
  } else if (category === 'hot' || category === 'popular') {
    games = gameData.filter(game => game.isPopular);
  } else if (category === 'incredible') {
    // Filter for games from Incredible Website - use the source property or filter by index for backwards compatibility
    games = gameData.filter(game => game.source === 'incredible' || (game.id.includes('tetris') && !game.source));
  } else if (category === 'crazygames') {
    // Filter for games from CrazyGames
    games = gameData.filter(game => game.source === 'crazygames');
  } else if (category.startsWith('letter-')) {
    const letter = category.replace('letter-', '');
    if (letter === '0-9') {
      games = gameData.filter(game => /^[0-9]/.test(game.title));
    } else {
      games = gameData.filter(game => game.title.toLowerCase().startsWith(letter));
    }
  } else if (category) {
    games = gameData.filter(game =>
      game.categories.some(cat => cat.toLowerCase() === category.toLowerCase())
    );
  }

  // Apply limit if provided
  if (limit) {
    games = games.slice(0, limit);
  }

  return (
    <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
      {games.length > 0 ? (
        games.map(game => (
          <div key={game.id}>
            <Link
              to={`/game/${game.id}`}
              className="game-tab"
            >
              <h3 className="title">{game.title}</h3>
              <p className="category">{game.categories[0]}</p>
              <span className="play-button">Play</span>
            </Link>
          </div>
        ))
      ) : (
        <div className="col-span-full py-8 text-center">
          <p className="text-lg text-gray-500">No games found in this category</p>
        </div>
      )}
    </div>
  );
};

export default GameGrid;
