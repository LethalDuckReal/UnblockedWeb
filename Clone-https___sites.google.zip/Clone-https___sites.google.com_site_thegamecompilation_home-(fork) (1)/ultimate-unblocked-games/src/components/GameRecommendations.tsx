import { FC, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { gameData, Game } from '../data/games';

interface GameRecommendationsProps {
  currentGameId?: string;
  limit?: number;
}

interface PlayHistoryItem {
  gameId: string;
  lastPlayed: string;
  playCount: number;
}

const GameRecommendations: FC<GameRecommendationsProps> = ({
  currentGameId,
  limit = 5
}) => {
  const [recommendations, setRecommendations] = useState<Game[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Get play history from localStorage
    const playHistory: PlayHistoryItem[] = JSON.parse(localStorage.getItem('playHistory') || '[]');

    if (playHistory.length === 0) {
      // If no play history, recommend popular games
      const popularGames = gameData
        .filter(game => game.isPopular && game.id !== currentGameId)
        .slice(0, limit);

      setRecommendations(popularGames);
      setLoading(false);
      return;
    }

    // Get the categories the user plays most often
    const categoryCounts: Record<string, number> = {};

    playHistory.forEach(item => {
      const game = gameData.find(g => g.id === item.gameId);
      if (game) {
        game.categories.forEach(category => {
          categoryCounts[category] = (categoryCounts[category] || 0) + item.playCount;
        });
      }
    });

    // Sort categories by play count
    const sortedCategories = Object.entries(categoryCounts)
      .sort((a, b) => b[1] - a[1])
      .map(entry => entry[0]);

    // Get games from favorite categories excluding already played games and current game
    const playedGameIds = playHistory.map(item => item.gameId);
    const recommendedGames: Game[] = [];

    // First try to find games in favorite categories
    for (const category of sortedCategories) {
      const gamesInCategory = gameData.filter(
        game =>
          !playedGameIds.includes(game.id) &&
          game.id !== currentGameId &&
          game.categories.includes(category)
      );

      recommendedGames.push(...gamesInCategory);

      if (recommendedGames.length >= limit) {
        break;
      }
    }

    // If we don't have enough recommendations, add popular games
    if (recommendedGames.length < limit) {
      const popularGames = gameData
        .filter(
          game =>
            game.isPopular &&
            !playedGameIds.includes(game.id) &&
            game.id !== currentGameId &&
            !recommendedGames.some(g => g.id === game.id)
        )
        .slice(0, limit - recommendedGames.length);

      recommendedGames.push(...popularGames);
    }

    // If we still don't have enough, add random games
    if (recommendedGames.length < limit) {
      const remainingGames = gameData
        .filter(
          game =>
            !playedGameIds.includes(game.id) &&
            game.id !== currentGameId &&
            !recommendedGames.some(g => g.id === game.id)
        )
        .slice(0, limit - recommendedGames.length);

      recommendedGames.push(...remainingGames);
    }

    setRecommendations(recommendedGames.slice(0, limit));
    setLoading(false);
  }, [currentGameId, limit]);

  if (loading) {
    return <div className="py-4 text-gray-500">Loading recommendations...</div>;
  }

  if (recommendations.length === 0) {
    return null;
  }

  return (
    <div className="w-full">
      <h2 className="mb-4 text-2xl font-bold text-gray-800">Recommended For You</h2>
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-5">
        {recommendations.map(game => (
          <Link
            key={game.id}
            to={`/game/${game.id}`}
            className="game-card"
          >
            <div className="aspect-square overflow-hidden relative group">
              <img
                src={game.thumbnail}
                alt={game.title}
                className="h-full w-full object-cover transition-transform group-hover:scale-110"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                <div className="bg-blue-600 text-white text-sm font-medium px-3 py-1 rounded-full">
                  Play Now
                </div>
              </div>
            </div>
            <div className="bg-white p-3">
              <h3 className="font-medium text-gray-900 truncate">{game.title}</h3>
              <p className="mt-1 text-sm text-gray-500 truncate">{game.categories[0]}</p>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
};

export default GameRecommendations;
